let input = "Qwer123!23" 
let strong = 0; 

function isUppercase(input) {
  if (typeof input === "string") {
    if (input === input.toUpperCase() && input !== input.toLowerCase()) {
      
      return true;
    }
  } else {
    return false;
}
}




function hasUppercase(input) {
  for(let i = 0; i < input.length; i++) {
    if (isUppercase(input[i])) {
      strong++;
      return true;
    }
  }
  return false;
}

function isLowercase(input) {
  if (typeof input === "string") {
    if (input !== input.toUpperCase() && input === input.toLowerCase()) {

      return true;
    };
  } else {
    return false;
}
}

function hasLowercase(input) {
  for(let i = 0; i < input.length; i++) {
    if (isLowercase(input[i])) {
      strong++;
      return true;
    }
  }
  return false;
}





function isLongEnough(input) {
  if (input.length >= 8) {
    strong++;
    return true;
  } else {
    return false;
  }
}

function hasSpecialchar(input) {
  if (/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(input)) {
    strong++
    return true;
  } else {
    return false; 
  }
}


function isPasswordValid(input) {
  
  let upper = hasUppercase(input);
  let lower = hasLowercase(input);
  let long = isLongEnough(input);
  let special = hasSpecialchar(input);
  

  if (upper && lower && long && special) {
    console.log("okay");
    return true;
  } else {
    console.log("nope");
    return false;
  }
}

input = prompt("password");
isPasswordValid(input);

